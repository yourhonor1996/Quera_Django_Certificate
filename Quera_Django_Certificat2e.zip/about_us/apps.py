from django.apps import AppConfig


class AboutUsConfig(AppConfig):
    name = 'about_us'
